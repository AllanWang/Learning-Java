//Allan Wang 260667681
public class LogicalOperators {
	public static void main (String[] args) {
		boolean[] b = { //write boolean array here
				false, true, false
		};
		System.out.println("iteration " + conjunctionIter(b));
		System.out.println("rec " + conjunctionRec(b));
		System.out.println("iteration disj " + disjunctionIter(b));
		System.out.println("rec disj " + disjunctionRec(b));
	}
	
	/*
	 * In reality, if any boolean returns false, the entire array will return false for conjunction
	 * For the sake of this assignment, the array will be checked in pairs
	 */
	
	//iterative method to check boolean conjunction
	public static boolean conjunctionIter (boolean[] b) {
		if (b == null || b.length == 0) {
			System.out.println("Null array, aborting...");
			return false;
		}
		if (b.length == 1) {
			return b[0];
		}
		boolean a = b[0]; //first value
		for (int i = 1; i < b.length; i++) {
			a = a && b[i]; //checkes saved value && next value
			if (!a) {
				return false;
			}
		}
		return true;
	}
	
	//recursive method to check boolean conjunction
	public static boolean conjunctionRec (boolean[] b) {
		if (b == null || b.length == 0) {
			System.out.println("Null array, aborting...");
			return false;
		}
		if (b.length == 1) {
			return b[0];
		}
		return andTrue(b, b[0], 1);
	}
	
	//checks the boolean in an array one at a time; returns false once a false boolean is found
	public static boolean andTrue (boolean[] b, boolean a, int i) {
		if (a && b[i]) {
			if (i >= (b.length-1)) {
				return true;
			} else {
				return andTrue(b, a, ++i);
			}
		}
		return false;
	}
	
	/*
	 * In reality, if the any boolean returns true, the entire array will return true for disjunction
	 * For the sake of this assignment, the array will be checked in pairs
	 */
	
	//iterative method to check boolean disjunction
	public static boolean disjunctionIter (boolean[] b) {
		if (b == null || b.length == 0) {
			System.out.println("Null array, aborting...");
			return false;
		}
		if (b.length == 1) {
			return b[0];
		}
		boolean a = b[0];
		for (int i = 1; i < b.length; i++) {
			a = a || b[i];
		}
		return a;
	}
	
	//recursive method to check boolean disjunction
	public static boolean disjunctionRec (boolean[] b) {
		if (b == null || b.length == 0) {
			System.out.println("Null array, aborting...");
			return false;
		}
		if (b.length == 1) {
			return b[0];
		}
		return orTrue(b, b[0], 1);
	}
	
	//compares two boolean using or, and goes to the next pair if previous is true
	public static boolean orTrue (boolean[] b, boolean a, int i) {
		a = a || b[i];
		if (i >= (b.length-1)) {
			return a;
		} else {
			return orTrue(b, a, ++i);
		}
	}
}
