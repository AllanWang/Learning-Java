//Allan Wang 260667681
/*
 * Class that will take a freqs file and the tfs for a file and return the tf-idf value
 * 
 * For the sake of supporting dr java, new Hashmap<>(); has the parameters within it
 */

import java.util.*;
import java.io.*;

public class KeywordExtractor {
	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("Please input (and only input) a directory.");
			return;
		}
		String dir = args[0]; // name of directory with input files
//		String dir = "./src/docs"; //for testing
		//validate directory
		if (dir.charAt(dir.length()-1) != '/') {
			dir += "/";
		}
		if (dir.charAt(0) == '.') {
			if (dir.charAt(1) != '/') {
				System.out.println("If you want to use the current directory, make sure it starts with \"./\"");
				return;
			}
		}
		try {
			outputPrint(dir, 40); //prints top 5 keys per txt in the console
//			outputGen("./src/docs/", 40); //writes top 5 keys per txt in output.txt	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static HashMap<String, Integer> computeTermFrequencies(String filename) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line;
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		while ((line = br.readLine()) != null) {
			String[] words = line.split(" ");
			for (String word : words) {
				word = normalize(word);
				if (word.length() == 0) { // word sometimes has no characters; don't include it
					continue;
				}
				/*
				 * The normalize function given fails to remove apostrophes if they are located at
				 * the first or last character in the "word"
				 * the try catch below will take care of that
				 */
				try {
					if (word.charAt(0) == '\'') {
						word = word.substring(1);
					}
					if (word.length() == 0) {
						continue;
					}
					if (word.charAt(word.length() - 1) == '\'') {
						word = word.substring(0, word.length() - 1);
					}
				} catch (Exception e) {
					System.out.println("Exception occured with word \"" + word + "\"; ignoring.");
					//String likely has only ' or spaces; ignore;
				}
				if (!map.containsKey(word)) {
					map.put(word, 1);
				} else {
					// key is already present
					map.put(word, map.get(word) + 1);
				}
			}
		}
		if (br != null) {
			br.close();
		}
		return map;
	}

	public static HashMap<String, Integer> readDocumentFrequencies(String filename) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line;
		HashMap<String, Integer> h = new HashMap<String, Integer>();
		while ((line = br.readLine()) != null) {
			String[] words = line.split(" ");
			if (words.length != 2) {
				System.out.println("There seems to be an error... This should not have happened; skipping a word.");
			} else {
				h.put(words[0], Integer.parseInt(words[1]));
			}
		}
		br.close();
		return h;
	}

	public static HashMap<String, Double> computeTFIDF(HashMap<String, Integer> tfs, HashMap<String, Integer> dfs,
			double nDocs) {
		HashMap<String, Double> map = new HashMap<String, Double>();
		for (String s : tfs.keySet()) {
			double d = ((double) tfs.get(s)) * Math.log(nDocs / dfs.get(s));
			map.put(s, d);
		}
		return map;
	}
	
	public static void outputPrint(String dir, int n) throws IOException {
		for (int i = 1; i <= n; i++) {
			HashMap<String, Integer> dfs = readDocumentFrequencies("freqs.txt");
			HashMap<String, Integer> tfs = computeTermFrequencies(dir + i + ".txt");
			HashMap<String, Double> td = computeTFIDF(tfs, dfs, (double) n);
			try {
				if (i != 1) {
					System.out.println(" ");
				}
				System.out.println(i + ".txt" + stringifyTopKeywords(td, 5));
			} catch (Exception e) {
				// This should never happen
				e.printStackTrace();
			}
		}
	}
	
	public static void outputGen(String dir, int n) throws IOException {
		Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"), "utf-8"));
		for (int i = 1; i <= n; i++) {
			HashMap<String, Integer> dfs = readDocumentFrequencies("freqs.txt");
			HashMap<String, Integer> tfs = computeTermFrequencies(dir + i + ".txt");
			HashMap<String, Double> td = computeTFIDF(tfs, dfs, (double) n);
			try {
				String s = new String();
				if (i != 1) {
					s += "\n\n";
				}
				s += i + ".txt" + stringifyTopKeywords(td, 5);
				writer.write(s);
			} catch (Exception e) {
				// This should never happen
				e.printStackTrace();
			}
		}
		System.out.println("output.txt created");
		if (writer != null) {
			writer.close();
		}
	}

	/**
	 * This method prints the top K keywords by TF-IDF in descending order.
	 */
	public static void printTopKeywords(HashMap<String, Double> tfidfs, int k) {
		ValueComparator vc = new ValueComparator(tfidfs);
		TreeMap<String, Double> sortedMap = new TreeMap<String, Double>(vc);
		sortedMap.putAll(tfidfs);

		int i = 0;
		for (Map.Entry<String, Double> entry : sortedMap.entrySet()) {
			String key = entry.getKey();
			Double value = entry.getValue();

			System.out.println(key + " " + value);
			i++;
			if (i >= k) {
				break;
			}
		}
	}
	
	//duplicate that will return a string
	public static String stringifyTopKeywords(HashMap<String, Double> tfidfs, int k) {
		ValueComparator vc = new ValueComparator(tfidfs);
		TreeMap<String, Double> sortedMap = new TreeMap<String, Double>(vc);
		sortedMap.putAll(tfidfs);
		String s = new String();
		int i = 0;
		for (Map.Entry<String, Double> entry : sortedMap.entrySet()) {
			String key = entry.getKey();
			Double value = entry.getValue();

			s += "\n" + key + " " + value;
			i++;
			if (i >= k) {
				break;
			}
		}
		return s;
	}
	
	//copied from DocumentFrequency
	public static String normalize(String word) {
		return word.replaceAll("[^a-zA-Z ']", "").toLowerCase();
	}
}

/*
 * This class makes printTopKeywords work. Do not modify.
 */
class ValueComparator implements Comparator<String> {

	Map<String, Double> map;

	public ValueComparator(Map<String, Double> base) {
		this.map = base;
	}

	public int compare(String a, String b) {
		if (map.get(a) >= map.get(b)) {
			return -1;
		} else {
			return 1;
		} // returning 0 would merge keys
	}
}

/*
 * This method worked quite well, as it shows the keywords that aren't appearing too often in other documents
 * that are key to understanding the current text file. For the most part, I can guess the topic of 
 * the file.
 */