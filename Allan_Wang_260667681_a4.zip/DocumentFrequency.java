//Allan Wang 260667681
/*
 * Class that will read all the words in a given directory and return a freqs.txt
 * containing the number of times each word as appeared in different documents
 * 
 * For the sake of supporting dr java, new Hashmap<>(); has the parameters within it
 */

import java.util.*;
import java.io.*;

public class DocumentFrequency {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("Please input (and only input) a directory.");
			return;
		}
		String dir = args[0]; // name of directory with input files
//		String dir = "./src/docs"; //for testing
		//validate directory
		if (dir.charAt(dir.length()-1) != '/') {
			dir += "/";
		}
		if (dir.charAt(0) == '.') {
			if (dir.charAt(1) != '/') {
				System.out.println("If you want to use the current directory, make sure it starts with \"./\"");
				return;
			}
		}
		HashMap<String, Integer> dfs = new HashMap<String, Integer>();
		try {
			dfs = extractDocumentFrequencies(dir, 40);
			writeDocumentFrequencies(dfs, "freqs.txt");
			System.out.println("Successfully wrote document frequency to freqs.txt");
		} catch (IOException e) {
			// Error
			e.printStackTrace();
		}
	}

	//extracts frequency from files in a directory
	public static HashMap<String, Integer> extractDocumentFrequencies(String directory, int nDocs) throws IOException {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for (int i = 1; i <= nDocs; i++) {
			for (String word : extractWordsFromDocument(directory + i + ".txt")) {
				if (!map.containsKey(word)) {
					map.put(word, 1);
				} else {
					// key is already present
					map.put(word, map.get(word) + 1);
				}
			}
		}
		return map;
	}

	//returns HashSets containing all the words in a document
	public static HashSet<String> extractWordsFromDocument(String filename) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line;
		HashSet<String> h = new HashSet<String>();
		while ((line = br.readLine()) != null) {
			String[] words = line.split(" ");
			for (String word : words) {
				word = normalize(word);
				if (word.length() == 0) { // word sometimes has no characters; don't include it
					continue;
				}
				/*
				 * The normalize function given fails to remove apostrophes if they are located at
				 * the first or last character in the "word"
				 * the try catch below will take care of that
				 * 
				 * There are other formatting errors such as hyphens in between that will create a false word
				 * but for the sake of this assignment, they will be kept as is
				 */
//				if (word == "'") {
//					continue;
//				}
				try {
					if (word.charAt(0) == '\'') { //leading '
						word = word.substring(1);
					}
					if (word.length() == 0) { //stop if word is now empty
						continue;
					}
					if (word.charAt(word.length() - 1) == '\'') { //lagging '
						word = word.substring(0, word.length() - 1);
					}
				} catch (Exception e) {
					System.out.println("Exception occured with word \"" + word + "\"; ignoring.");
					//String likely has only ' or spaces; ignore;
				}
				h.add(word); //add word to HashSet
			}
		}
		if (br != null) {
			br.close(); //close reader
		}
		return h;
	}

	//Takes a hashmap and writes the values to a file
	public static void writeDocumentFrequencies(HashMap<String, Integer> dfs, String filename) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename), "utf-8"))) {
			List<String> l = new ArrayList<>();
			for (String s : dfs.keySet()) {
				l.add(s);
			}
			Collections.sort(l);
			for (String s : l) {
				writer.write(s + " " + dfs.get(s) + "\n");

			}
			if (writer != null) {
				writer.close();
			}
		} catch (Exception e) {
			// This should never happen
			e.printStackTrace();
		}

	}

	/*
	 * This method "normalizes" a word, stripping extra whitespace and
	 * punctuation. Do not modify.
	 */
	public static String normalize(String word) {
		return word.replaceAll("[^a-zA-Z ']", "").toLowerCase();
	}

}